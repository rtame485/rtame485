For running these yuu have to download cisco packet tracer first.

